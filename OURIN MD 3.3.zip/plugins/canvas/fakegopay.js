import axios from "axios";
import te from "../../src/lib/ourin-error.js";

const pluginConfig = {
    name: "fakegopay",
    alias: ["fakegopay"],
    category: "canvas",
    description: "Membuat canvas fake gopay",
    usage: ".fakegopay <saldo>|<coin>|<terpakai>|<bulan>",
    example: ".fakegopay 100000|500|20000|Januari",
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 2,
    isEnabled: true,
};

async function handler(m, { sock, text }) {
    if (!text) return m.reply(`Format salah!\n\n> Contoh: .fakegopay 100000|500|20000|Januari`);
    const [saldo, coin, terpakai, bulan] = text.split("|").map(v => v.trim());
    if (!saldo || !coin || !terpakai || !bulan) return m.reply(`Pastikan semua argumen diisi dengan benar, dipisah dengan tanda |.`);
    
    await m.react("🕕");
    try {
        const url = `https://kyzznekoo.zone.id/api/canvas/fakegopay?saldo=${encodeURIComponent(saldo)}&coin=${encodeURIComponent(coin)}&terpakai=${encodeURIComponent(terpakai)}&bulan=${encodeURIComponent(bulan)}`;
        const res = await axios.get(url, {
            responseType: 'arraybuffer',
            headers: {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36",
                "Content-Type": "application/json"
            }
        });
        await sock.sendMessage(m.chat, { image: Buffer.from(res.data), caption: "✅ Berhasil membuat fake gopay" }, { quoted: m });
        await m.react("✅");
    } catch (e) {
        console.error("[FakeGopay Error]", e);
        await m.react("❌");
        m.reply(te(m.prefix, m.command, m.pushName));
    }
}

export { pluginConfig as config, handler };
